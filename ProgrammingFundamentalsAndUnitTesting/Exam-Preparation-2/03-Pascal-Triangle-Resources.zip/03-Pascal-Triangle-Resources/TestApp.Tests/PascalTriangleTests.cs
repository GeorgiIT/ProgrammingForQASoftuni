using System;
using NUnit.Framework;

namespace TestApp.Tests;

public class PascalTriangleTests
{
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    public void Test_PrintTriangle_ShouldReturnCorrectString(int n, string expected)
    {
        // TODO: implement the test and finish the test cases
    }
}
