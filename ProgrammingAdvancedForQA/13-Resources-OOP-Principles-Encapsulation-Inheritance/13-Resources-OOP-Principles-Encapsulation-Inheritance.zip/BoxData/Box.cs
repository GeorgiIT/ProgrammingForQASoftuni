﻿using System;
using System.Text;

namespace BoxData;

public class Box
{

}
