﻿namespace TestApp.Store;

public class Item
{
    public string Name { get; set; } = null!;

    public decimal Price { get; set; }
}
