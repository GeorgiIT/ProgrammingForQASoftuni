namespace Animals.Models;

public abstract class Animal
{
}
