﻿namespace Articles
{
    public class Program
    {
        static void Main(string[] args)
        {

            string[] command = Console.ReadLine().Split(",");
            string title = command[0];
            string content = command[1];
            string author = command[2];
            Article article = new Article(title, content, author);
            
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split(":");
                string actualCommand = input[0];
                string textToBeChanged = input[1];

                switch (actualCommand)
                {
                    case "Edit":
                        article.EditContent(textToBeChanged);
                      
                        break;
                    case "ChangeAuthor":
                        article.ChangeAuthor(textToBeChanged);
                        break;
                    case "Rename":
                        article.ChangeTitle(textToBeChanged);
                        break;
                }
            }
            Console.WriteLine(article);

        }
    }
}
