﻿namespace TestApp.Vehicle;

public class Car
{
    public string Brand { get; set; } = null!;

    public string Model { get; set; } = null!;

    public int HorsePower { get; set; }
}
