﻿using System;
using NUnit.Framework;

namespace TestApp.Tests;

public class FoldSumTests
{
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    //[TestCase()]
    public void Test_FoldArray_ReturnsCorrectString(int[] arr, string expected)
    {
        // TODO: implement the test and finish the test cases
    }
}
