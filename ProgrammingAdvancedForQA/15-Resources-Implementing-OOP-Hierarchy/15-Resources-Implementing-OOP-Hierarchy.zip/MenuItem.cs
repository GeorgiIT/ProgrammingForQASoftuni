namespace ExerciseOopHierarchy;

public abstract class MenuItem
{

}
