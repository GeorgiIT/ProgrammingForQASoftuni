﻿using NUnit.Framework;

using System;

namespace TestApp.UnitTests;

public class ArticleTests
{
    // TODO: write the setup method

    // TODO: finish test
    [Test]
    public void Test_AddArticles_ReturnsArticleWithCorrectData()
    {
        // Arrange

        // Act

        // Assert
        //Assert.That(result.ArticleList, Has.Count.EqualTo(3));
        //Assert.That(result.ArticleList[0].Title, Is.EqualTo("Article"));
        //Assert.That(result.ArticleList[1].Content, Is.EqualTo("Content2"));
        //Assert.That(result.ArticleList[2].Author, Is.EqualTo("Author3"));
    }

    [Test]
    public void Test_GetArticleList_SortsArticlesByTitle()
    {
        // TODO: finish test
    }

    [Test]
    public void Test_GetArticleList_ReturnsEmptyString_WhenInvalidPrintCriteria()
    {
        // TODO: finish test
    }
}
