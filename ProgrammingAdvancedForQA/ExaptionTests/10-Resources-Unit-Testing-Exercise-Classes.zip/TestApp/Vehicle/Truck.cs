﻿namespace TestApp.Vehicle;

public class Truck
{
    public string Brand { get; set; } = null!;

    public string Model { get; set; } = null!;

    public int Weight { get; set; }
}
