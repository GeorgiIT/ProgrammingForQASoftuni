﻿namespace TestApp;

public class Calculate
{
    public int Addition(int a, int b)
    {
        return a + b;
    }

    public int Subtraction(int a, int b)
    {
        return a - b; 
    }
}
