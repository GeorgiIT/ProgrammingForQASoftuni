﻿using System;

namespace PersonInfo;

public class Person
{

}
