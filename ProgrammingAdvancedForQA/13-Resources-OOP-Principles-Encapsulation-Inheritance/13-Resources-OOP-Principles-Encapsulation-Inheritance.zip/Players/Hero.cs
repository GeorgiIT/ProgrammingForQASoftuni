﻿namespace Players;

public class Hero
{

}
