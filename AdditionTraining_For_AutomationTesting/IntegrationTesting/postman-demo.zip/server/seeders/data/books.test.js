module.exports = () => {
  return [{
    title: 'Don\'t Waste Your Life',
    author: 'John Piper',
    publicationDate: new Date(2003, 4, 16),
    isbn: '1593281056',
    createdAt: new Date(),
    updatedAt: new Date()
  }];
};