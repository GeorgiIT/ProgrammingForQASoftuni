namespace Cars;

public interface ICar
{
 
}
