﻿namespace MoviesLibraryAPI.Controllers.Contracts
{
    public interface IConsoleEngine
    {
        Task Run();
    }
}
